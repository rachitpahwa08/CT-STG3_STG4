package handson2abstractfactorypattern;
public class MercedesTyre  extends Tire{

	public MercedesTyre() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("Mercedes Tyre");
	}

}