package handson3adapterfactory;
public class BugattiVeyron implements Movable {

	@Override
	public double getSpeed() {
		// TODO Auto-generated method stub
		return 268;
		}

	@Override
	public double getPrice() {
		// TODO Auto-generated method stub
		return 1_900_000;
	}
	

}