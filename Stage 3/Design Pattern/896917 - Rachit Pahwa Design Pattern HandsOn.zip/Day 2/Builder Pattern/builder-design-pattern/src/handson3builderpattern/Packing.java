package handson3builderpattern;
public interface Packing {
	public String pack();
}