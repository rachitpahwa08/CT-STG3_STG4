package handson2abstractfactorypattern;
public class AudiTyre extends Tire{

	public AudiTyre() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("Audi Tyre");
	}

}