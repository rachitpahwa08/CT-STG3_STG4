package handson2abstractfactorypattern;
public class MercedesHeadlight extends Headlight {

	public MercedesHeadlight() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("Mercedes Headlight");
	}

}