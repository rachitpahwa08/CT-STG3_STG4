package handson2abstractfactorypattern;
public abstract class Tire {

}