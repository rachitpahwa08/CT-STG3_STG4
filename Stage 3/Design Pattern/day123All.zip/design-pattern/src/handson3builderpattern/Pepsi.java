package handson3builderpattern;
public class Pepsi extends ColdDrink{

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "Pepsi";
	}

	@Override
	public float price() {
		// TODO Auto-generated method stub
		return 30.0f;
	}

}