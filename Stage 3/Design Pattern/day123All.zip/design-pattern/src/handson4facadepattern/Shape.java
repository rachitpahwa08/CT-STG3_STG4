package handson4facadepattern;
public interface Shape {
	public void draw();

}