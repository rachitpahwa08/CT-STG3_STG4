package handson6observerpattern;
public interface Observer {
	public void update(Message m);
}