package abstractdesignpattern;

public interface Sim {
	void call();
	void browse();
	void setDataSpeed(double speed);
}
