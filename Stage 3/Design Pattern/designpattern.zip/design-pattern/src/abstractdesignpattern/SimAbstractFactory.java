package abstractdesignpattern;

public abstract class SimAbstractFactory {
	abstract Sim getSim(String provider);
}
