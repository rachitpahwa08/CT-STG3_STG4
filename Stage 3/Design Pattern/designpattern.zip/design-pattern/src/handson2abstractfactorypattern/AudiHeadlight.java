package handson2abstractfactorypattern;
public class AudiHeadlight extends Headlight {

	public AudiHeadlight() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("Audi Headlight");
	}
	
}