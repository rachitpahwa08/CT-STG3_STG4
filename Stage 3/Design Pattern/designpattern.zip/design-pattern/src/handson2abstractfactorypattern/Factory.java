package handson2abstractfactorypattern;
public abstract class Factory {
	public abstract Headlight makeHeadLight();
	public abstract Tire makeTire();
	

}