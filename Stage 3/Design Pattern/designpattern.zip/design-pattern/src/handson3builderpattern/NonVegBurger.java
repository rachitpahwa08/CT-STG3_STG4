package handson3builderpattern;
public class NonVegBurger extends Burger {

	@Override
	public String name() {
		// TODO Auto-generated method stub
		return "Chicken Burger";
	}

	@Override
	public float price() {
		// TODO Auto-generated method stub
		return 50.0f;
	}
	

}