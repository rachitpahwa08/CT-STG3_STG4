package com.cognizant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.service.CountryService;
import com.cognizant.ormlearn.service.exception.CountryNotFoundException;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SpringBootApplication
public class OrmLearnApplication {
	private static CountryService countryService;
	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);

	private static void testGetAllCountries() {
		LOGGER.info("Start");
		List<Country> countries = countryService.getAllCountries();
		LOGGER.debug("countries={}", countries);
		LOGGER.info("End");
	}

	private static void getAllCountriesTest() throws CountryNotFoundException {
		LOGGER.info("Start");
		Country country = countryService.findCountryByCode("IN");
		LOGGER.debug("Country:{}", country);
		LOGGER.info("End");
	}
	
	private static void testAddCountry() throws CountryNotFoundException {
		LOGGER.info("Start");
		Country country = new Country();
		country.setCode("TS");
		country.setName("Test Country JPA");
		countryService.addCountry(country);
		LOGGER.debug("Country:{}", countryService.findCountryByCode("TS"));
		LOGGER.info("End");
	}
	
	private static void updateCountry() throws CountryNotFoundException {
		LOGGER.info("Start");
		Country country = countryService.findCountryByCode("TS");
		LOGGER.debug("Country Before Updation:{}", country);
		countryService.updateCountry("Test Country", "TS");
		LOGGER.debug("Country After Updation:{}", countryService.findCountryByCode("TS"));
		LOGGER.info("End");
	}
	public static void deleteCountry() throws CountryNotFoundException {
		LOGGER.info("Start");
		Country country = countryService.findCountryByCode("TS");
		LOGGER.debug("Country Before Deletion:{}", country);
		countryService.deleteCountry("TS");
		LOGGER.debug("Country After Deletion:{}", countryService.findCountryByCode("TS"));
	}

	public static void main(String[] args) {

		ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);
		LOGGER.info("Inside main");
		countryService = context.getBean(CountryService.class);
		//testGetAllCountries();
//		try {
//			getAllCountriesTest();
//		} catch (CountryNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		try {
//			testAddCountry();
//		} catch (CountryNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		try {
//			updateCountry();
//		} catch (CountryNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		try {
			deleteCountry();
		} catch (CountryNotFoundException e) {
			// TODO Auto-generated catch block
			LOGGER.debug(e.getLocalizedMessage());
			LOGGER.info("End");
			//e.printStackTrace();
		}
	}

}
