package com.cognizant.ormlearn.service.exception;

public class CountryNotFoundException extends Exception{

	public CountryNotFoundException() {
		super("No Country Found");
		// TODO Auto-generated constructor stub
	}


	
}
