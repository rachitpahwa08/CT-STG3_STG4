package com.cognizant.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.model.CountryPattern;
import com.cognizant.ormlearn.service.CountryService;

@Controller
public class CountryContoller {

	@Autowired
	private CountryService countryService;

	@GetMapping("/searchCountry")
	public String showSearchPage(@ModelAttribute("countryPattern") CountryPattern countryPattern) {
		
		return "search";
	}
	@GetMapping("/getCountriesByPattern")
	public String getCountryByPattern(@ModelAttribute("countryPattern") CountryPattern countryPattern,ModelMap model) {
		System.out.println("Country Patter"+countryPattern);
		List<Country> countries=countryService.getCountryByMatch(countryPattern.getSearchPattern());
		System.out.println(countries);
		model.addAttribute("countries", countries);
		return "result";
	}
	@GetMapping("/getCountriesByLetter")
	public String getCountryByLetter(@ModelAttribute("countryPattern") CountryPattern countryPattern,ModelMap model) {
		System.out.println("Country Patter"+countryPattern);
		List<Country> countries=countryService.getCountryByFirstLetter(countryPattern.getSearchPattern());
		System.out.println(countries);
		model.addAttribute("countries", countries);
		return "result";
	}
}
