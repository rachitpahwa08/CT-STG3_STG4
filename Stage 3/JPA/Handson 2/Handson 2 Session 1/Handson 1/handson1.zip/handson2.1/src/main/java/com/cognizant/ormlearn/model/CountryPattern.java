package com.cognizant.ormlearn.model;

public class CountryPattern {
private String searchPattern;

public String getSearchPattern() {
	return searchPattern;
}

public void setSearchPattern(String searchPattern) {
	this.searchPattern = searchPattern;
}

@Override
public String toString() {
	return "CountryPattern [searchPattern=" + searchPattern + "]";
}

}
