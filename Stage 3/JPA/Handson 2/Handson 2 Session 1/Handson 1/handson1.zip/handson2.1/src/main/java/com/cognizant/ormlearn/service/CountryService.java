package com.cognizant.ormlearn.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.repositry.CountryRepository;

@Service
public class CountryService {

	@Autowired
	private CountryRepository countryRepository;
	
	public List<Country> getCountryByMatch(String match){
		return countryRepository.findByNameContainingOrderByNameAsc(match);
	}
	public List<Country> getCountryByFirstLetter(String match){
		return countryRepository.findByNameStartingWith(match);
	}
	
}
